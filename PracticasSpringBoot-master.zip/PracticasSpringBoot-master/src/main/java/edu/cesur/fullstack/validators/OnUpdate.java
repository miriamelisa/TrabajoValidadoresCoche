package edu.cesur.fullstack.validators;

public interface OnUpdate {

}

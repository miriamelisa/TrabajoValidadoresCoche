package edu.cesur.fullstack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrimerProyectoSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrimerProyectoSpringBootApplication.class, args);
	}

}
